# Travel and Hotels


## Getting to the venue
The venue, [Wood Lane Countryside Centre, Sheffield](https://maps.app.goo.gl/JTQrL8GEKJfoqV6A7), is about 12 minutes walk uphill from the Malin Bridge tram stop. There is a direct Blue tram from Sheffield Station, running about every 10 minutes.

There are also frequent 81 and 82 buses from the town centre to a stop ~4mins from the venue.

There is extremely limited parking at the venue itself, but you may find roadside parking on one of the residential streets nearby. There is also free parking at Malin Bridge Park and Ride, next to Malin Bridge tram stop. 


## Hotels in Sheffield

