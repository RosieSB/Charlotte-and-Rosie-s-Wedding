# Charlotte and Rosie's Wedding

On these pages you will hopefully find all the information you need about the day

We hope you can make it!

```{admonition} RSVP
[Click here](https://forms.gle/dAgJUgQyavHhbF7VA) to RSVP!
```

You can also email [rshewellbrockway@gmail.com](mailto:rshewellbrockway@gmail.com) or [ceferris44@gmail.com](mailto:ceferris44@gmail.com) to ask us any questions about the day.



Also on this page:
```{tableofcontents}
```
