# Accessibility information

The venue is wheel chair accessible and has a lift.

Find out about hearing loop!

There will be a quiet room for anyone wanting a break. 

Another smallish room will have toys and games, at least of which may interest children.

Baby changing? Breast feeding?

Toilets?


