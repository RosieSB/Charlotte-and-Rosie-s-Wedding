# Food and Drink

The main meal will be a buffet lunch, served after the ceremony. It will be Lebanese cuisine, supplied by one our favourite restaurants, [Mount Lebanon](https://www.mountlebanon.co.uk/).

There will also be several chocolate brownie towers, from [Scrumptious by Lucy](https://www.scrumptiousbylucy.com/).

There will be meat, vegetarian and vegan options available, in a ratio determined by how you respond to the [RSVP form](https://forms.google.com). Please let us know about any other dietary requirements, and we will make sure there is something tasty for you to eat.

Tea, coffee and soft drinks will be available throughout the day. 

Prosecco and a non-alcoholic alternative will be served just after the ceremony. The venue has a pay bar that will be open for other alcoholic and non-alcoholic drinks.
