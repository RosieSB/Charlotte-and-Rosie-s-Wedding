# Rough itinary
<div align="center">
            
|    	Time 	   |  Suggested activity |
|:------------:|:-------------------:|
| 11:30--12:00 | 	 		  Arrive 		   | 
| 12:00--13:00 |  Marriage ceremony  |	
| 13:00--23:00 | Food, drink, games, <br/>  talk to each other, <br/> chase cousins around garden, <br/> naps, cuddle Eevee, <br/>  silent disco at some point |
| 	  23:00    | 			Bedtime 		|
</div>
